<?php 

class MessageAction extends Action
{
	public function index()
	{


		$User = M("message"); // 连接表
            //分页
            //1.计算总数
            $count = $User->count();
            //2.导入分页类
            import("ORG.Util.Page");
            //3.实例化分页类,就是赋值new Page(总数, 页数);
            $p = new Page($count, 3);
            //4.分页显示输出
            $page = $p->show();

            // 当前页数据查询,order()是排序函数
            $list = $User->order('id DESC')->limit($p->firstRow.','.$p->listRows)->select();//order('id ASC')按id从小到大

            // 赋值赋值
            $this->assign('page', $page);
            $this->assign('data', $list);


      	  	$this->display();//显示页面
      	 }

      	 function addmessage()
      	 {
      	 		$value1 = session('username');
      	 		$User = M("message"); 

      	 		$User->username = $value1;
				$User->message = $_POST['message'];
				 
				$i=$User->add();// 把数据对象添加到数据库

				if($i==0)
				{
					$this->error('发表失败');
				}

				else
				{
					$this->success('发表成功');
				}
      	 }


}

?>