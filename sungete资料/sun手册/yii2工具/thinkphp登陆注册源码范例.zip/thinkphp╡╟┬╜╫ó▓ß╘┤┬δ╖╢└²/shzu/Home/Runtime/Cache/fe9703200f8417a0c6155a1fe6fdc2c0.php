<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html  

PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"

"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" >

<html>
<head>
<title>欢迎</title>
</head>


<body>
<center>
<form action='__URL__/do_login' method='post' name='myForm'> 
	<input type="text" name="username" placeholder="用户名"><br><br>
	<input type="password" name="password" placeholder="密码"><br><br>
	<input type="tsxt" name="code" placeholder="验证码，点击刷新"><br><br>
	<img src="__APP__/Public/code" onclick='this.src=this.src+"?"+Math.random()'/><br><br>
	<input type="submit" style="width:155px;">
</from>
<br><br>
如果您没有账号点击<a href="/shzu/index.php/Add">这里</a>
</center>
</body>
</html>