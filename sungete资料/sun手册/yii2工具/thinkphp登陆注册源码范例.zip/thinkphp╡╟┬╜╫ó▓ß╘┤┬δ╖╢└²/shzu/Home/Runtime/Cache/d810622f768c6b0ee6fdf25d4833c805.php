<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html

PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"

"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" >
<html>
<head>
<title>simple document</title>
<link rel='stylesheet' type='text/css' href=''/>
<script src=""></script>
</head>
<body>
<center>
<p>个人信息</p>
ID:<?php echo ($id); ?><br><br>
账号:<?php echo ($username); ?>
</center>
</body>
</html>